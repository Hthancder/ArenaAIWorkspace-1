# Tabspace 0.23 — bản thử nghiệm

## Cài vào Chrome
1. Giải nén file ZIP vào một thư mục cố định. Đừng xóa thư mục sau khi cài.
2. Truy cập `chrome://extensions`, bật **Chế độ dành cho nhà phát triển**.
3. Chọn **Tải tiện ích đã giải nén** và chọn thư mục chứa `manifest.json`.
4. Ghim Tabspace trên thanh công cụ; nhấn icon để mở popup, chọn **Mở không gian quản lý**. Có thể chỉnh phím tắt tại `chrome://extensions/shortcuts`.

## Kiểm thử
- Mở **Hộp để sau** ở sidebar để xem riêng các tab đã lưu nhanh. Chọn tab để mở, gắn tag, chuyển sang nhóm khác hoặc chuyển vào thùng rác; cũng có thể thao tác trong Nhóm đã lưu. Popup lưu bản sao của tab hiện tại vào hộp này.
- Khi nhập sao lưu chứa Hộp để sau, chế độ thêm gộp các tab vào hộp hiện có (giữ tên và thiết lập của hộp hiện có, không tự loại tab trùng); chế độ thay thế dùng hộp từ file. Những nhóm Để sau đã được nhập thành nhóm thường trong phiên bản trước không tự chuyển vào hộp: hãy chuyển tab thủ công nếu muốn.
- Trong **Tab đang mở**, lọc theo cửa sổ và trạng thái; kết hợp được với tìm kiếm. Bộ lọc chỉ áp dụng cho màn hình này và giữ trong lúc trang quản lý còn mở. Số thứ tự cửa sổ có thể đổi khi cửa sổ đóng. Tab đã chọn nhưng bị lọc ẩn vẫn được tính trong thao tác hàng loạt; kiểm tra số tab ẩn và bản xem trước. Xóa bộ lọc không xóa lựa chọn.
- Ghim hoặc bỏ ghim từng tab trong danh sách, hoặc chọn nhiều tab rồi xem trước và bỏ chọn trong hộp thoại. Tab đã chọn nhưng bị tìm kiếm ẩn vẫn được tính. Chrome có thể đổi vị trí tab; khi ghim tab trong nhóm Chrome, tab có thể bị đưa ra khỏi nhóm. Trạng thái được kiểm tra lại trước khi thao tác.
- Chọn nhiều tab đang mở và dùng **Cho tab nghỉ** để xem trước, bỏ chọn và chạy. Tab đang xem, ghim, đang phát âm thanh và đã nghỉ được bỏ qua; kết quả liệt kê từng tab.
- Chọn tab đang mở và dùng **Tạo nhóm Chrome** hoặc **Bỏ nhóm Chrome**. Tạo nhóm chỉ áp dụng một cửa sổ, bỏ qua tab ghim; tab đã thuộc nhóm khác có thể được chuyển. Nhấn nhãn nhóm ở hàng tab để chỉnh tên, màu và thu gọn. Nhóm Chrome khác nhóm đã lưu Tabspace; màu Chrome dùng bảng màu cố định.
- Nhóm có ghi chú, nút yêu thích và thu gọn/mở rộng; nhóm yêu thích được ưu tiên ở sidebar. Khi tìm kiếm, nhóm được mở tạm thời để thấy kết quả. Các mục đã chọn nhưng bị ẩn vẫn được tính trong thao tác hàng loạt và được báo ở thanh chọn.
- Trong **Nhóm đã lưu**, dùng ↑/↓ để sắp xếp nhóm và tab. Kéo tay nắm ⠿ của tab lên một tab khác để đặt trước, hoặc thả vào tiêu đề nhóm để chuyển về cuối nhóm. Xóa từ khóa tìm kiếm trước khi sắp xếp; tag và ghi chú được giữ nguyên.
- Trong **Nhóm đã lưu**, **Phiên đã lưu** và **Thùng rác**, chọn bằng checkbox hoặc “Chọn mục đang thấy”; kiểm tra bản xem trước trước khi thao tác hàng loạt. Có thể mở nhiều tab đã lưu hoặc thêm/gỡ tag hàng loạt. Tag nhóm và tab được sửa riêng. Nhóm đã chọn bao gồm các tab bên trong khi mở hoặc chuyển thùng rác. Tab trong thùng rác chỉ khôi phục được khi nhóm gốc tồn tại.
- Trong **Tab trùng**, xem các tab http/https có URL giống hệt trên nhiều cửa sổ. Không tự chọn hoặc đóng; bạn có thể chọn tab và lưu hoặc lưu & đóng sau xác nhận. Tab cùng URL có thể chứa nội dung hoặc biểu mẫu khác nhau.
- Popup ưu tiên hiển thị tab ở cuối thanh tab của cửa sổ hiện tại, sau đó đến các cửa sổ khác; đây là vị trí trên thanh tab, không phải thời gian truy cập gần nhất. Nhấn Xem thêm để xem từng lượt sáu tab, hoặc Thu gọn để trở về sáu tab đầu. Popup hỗ trợ lưu bản sao, chuyển sang màn hình xác nhận lưu & đóng, tìm/chuyển tab, cho tab nền đủ điều kiện nghỉ sau xác nhận và truy cập nhanh ba preset mới tạo. Tab đang hiển thị trong mỗi cửa sổ, ghim hoặc phát âm thanh không được cho nghỉ từ popup.
- Chọn **Tìm tất cả** để tìm đồng thời tab đang mở, nhóm, tab đã lưu, phiên và preset. Chọn **Tag** để xem số nhóm và tab gắn mỗi tag. Tab không tự kế thừa tag của nhóm; nội dung trang không được tìm kiếm.
- Chọn các tab đang mở, dùng **Lưu đã chọn** để lưu bản sao hoặc **Lưu & đóng đã chọn** để lưu trước rồi đóng. Tạo/chỉnh nhóm, mở từng tab hoặc cả nhóm, thêm tag cho nhóm và tab, ghi chú cho tab, chuyển bản lưu giữa các nhóm và tìm kiếm theo tag/ghi chú.
- Nút **Nghỉ** cho tab nền (không ghim, không phát âm thanh) vào trạng thái discard sau xác nhận. Chrome có thể từ chối; trang sẽ tải lại khi mở và trạng thái chưa lưu có thể mất.
- Trong **Thùng rác**, khôi phục hoặc xóa vĩnh viễn nhóm, tab đã lưu và phiên đã xóa từ phiên bản này. Không tự xóa theo thời gian; dữ liệu có trong file sao lưu. Nếu nhóm gốc bị xóa, khôi phục nhóm trước khi khôi phục tab.
- Trong **Lịch sử dọn**, xem kết quả các lượt lưu & đóng mới và mở lại các tab xác nhận đã đóng. Nhật ký được xuất trong JSON; lịch sử nhập lại có thể trỏ tới các trang đã mở trên thiết bị khác. Trạng thái không rõ cần kiểm tra thủ công; không thực hiện cùng lúc trên hai cửa sổ Tabspace.
- Trong **Preset dọn tab**, tạo preset với tên miền, URL chính xác hoặc đường dẫn và nhóm đích; mục URL và ngoại lệ cho phép loại trừ, sau đó xem trước và chọn tab để lưu & đóng. Tab đang xem, ghim, phát âm thanh hoặc ẩn danh được bỏ qua. Đường dẫn khớp theo từng đoạn, phân biệt scheme và cổng, bỏ qua query và fragment; URL chính xác xét cả query và fragment. Tên miền con áp dụng cho cả bao gồm và loại trừ tên miền. Không phân biệt tài khoản theo URL; Chrome không cho biết chắc tab có dữ liệu chưa lưu.
- Trong **Phiên đã lưu**, lưu thủ công các tab web trong cửa sổ thường; chọn từng tab để mở lại trong cửa sổ mới. Phiên mới lưu có thể bao gồm tên, màu, trạng thái thu gọn của nhóm Chrome; chọn có tạo lại nhóm khi mở hay không. Phiên cũ không có thông tin nhóm. Bản lưu không chứa form hoặc lịch sử điều hướng; các trang có thể tải ngay. Giữ trang Tabspace mở cho đến khi có kết quả; nếu bị gián đoạn, kiểm tra tab đã mở trước khi thử lại.
- Trong **Cài đặt & sao lưu**, xuất JSON; nhập để gộp hoặc thay thế. File chứa nhóm, phiên, preset, thùng rác, lịch sử và có thể chứa URL hoặc dữ liệu nhạy cảm. Chế độ thay thế giữ lịch sử và thùng rác cũ rồi thêm từ file. Sao lưu ra ngoài Chrome profile.

- Thời gian trong giao diện hiển thị giờ cho hôm nay, “Hôm qua” cho ngày trước đó và ngày cho những ngày khác. Di chuột hoặc dùng bàn phím focus để xem ngày giờ đầy đủ theo múi giờ thiết bị.

Các thao tác ghi dữ liệu của các trang Tabspace và popup dùng cùng một khóa: nếu đang có thao tác khác, hãy chờ rồi thử lại. Nếu biểu mẫu nhóm, tag/ghi chú tab hoặc preset đã bị sửa ở nơi khác, hãy đóng và mở lại biểu mẫu để tránh ghi đè. Không hỗ trợ các phiên bản extension cũ đang cùng hoạt động.

Favicon dùng API favicon của Chrome (quyền `favicon`); giao diện không tải trực tiếp URL favicon của website. Icon có thể dùng biểu tượng mặc định khi Chrome không có trong cache.

## Giới hạn quan trọng
Đây là bản thử nghiệm đầu tiên, không phải bản hoàn chỉnh theo tài liệu thiết kế. Chưa có preset tự động, lịch, tự động đóng, workspace, snapshot tự động, âm thanh tùy chỉnh, thông báo nền, đồng bộ hoặc bảo vệ tùy chỉnh. Xóa vĩnh viễn trong thùng rác không thể hoàn tác. Chỉ lưu URL http/https; Chrome có thể không cho mở hoặc thao tác một số tab. Lưu & đóng không bảo toàn nội dung chưa lưu hay trạng thái trang; chỉ dùng với trang bạn biết an toàn. Việc nhập thay thế sẽ xóa dữ liệu đang lưu. Không dùng extension làm bản sao lưu duy nhất.
